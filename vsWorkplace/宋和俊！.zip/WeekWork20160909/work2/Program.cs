﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace work2
{
    class Test
    {
        public void GetMax(int[] a, out int max, out int min)
        {
            max = int.MinValue;
            min = int.MaxValue;
            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] > max) max = a[i];
                if (a[i] < min) min = a[i];
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = { 1, 100, 2, 3, 4 };
            int max = 0;
            int min = 0;
            Test t = new Test();
            t.GetMax(a, out max, out min);
            Console.WriteLine("Max = {0}; Min = {1}", max, min);


        }
    }
}
