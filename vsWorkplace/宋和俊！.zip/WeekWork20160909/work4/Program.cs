﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace work4
{
    class Program
    {
        static void Main(string[] args)
        {
            int m, i, j;
	        for (i = 1; i<9; i++)
	        {
		        for (j = 1; j<9; j++)
		        {
			        for (m = 32; m<100; m++)//
			        {
				        if (m*m == (1000 * i + 100 * i + 10 * j + j))
				        {
					
					        
                            Console.WriteLine("{0}{1}{2}{3}", i, i, j, j);
				        }
			        }
		        }
	        }
        }
    }
}
