﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeekWork20160909
{
    class Program
    {
        static List<double> Que(ref double number1, ref double number2, ref double number3)
        {
            List<double> ls = new List<double>();
            ls.Add(number1);
            ls.Add(number2);
            ls.Add(number3);
            for (int i = 0; i < ls.Count; i++)
            {
                for (int j = 0; j < ls.Count - i - 1; j++)
                {
                    double temp;
                    if (ls[j] > ls[j + 1])
                    {
                        temp = ls[j];
                        ls[j] = ls[j + 1];
                        ls[j + 1] = temp;
                    }

                }

            }
            return ls;

        }

        static void Main(string[] args)
        {
            /*******************第一题**********************/
            /*从键盘上输入三个double类型的数，自定义       */
            /* 方法，以从小到大的顺序排序,以引用型参       */
            /* 数调用方法，然后返回主方法输出结果。        */
            /***********************************************/
            double num1;
            double num2;
            double num3;
            Console.WriteLine("请输入第一个double类型的数:");
            num1 = double.Parse(Console.ReadLine());
            Console.WriteLine("请输入第二个double类型的数:");
            num2 = double.Parse(Console.ReadLine());
            Console.WriteLine("请输入第三个double类型的数:");
            num3 = double.Parse(Console.ReadLine());
            List<double> Row = Que(ref num1, ref num2, ref num3);

            Console.WriteLine(Row[0]);
            Console.WriteLine(Row[1]);
            Console.WriteLine(Row[2]);





        }
    }
}
