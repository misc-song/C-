﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace work3
{
    class Program
    {
        static void Main(string[] args)
        {
            string str;


            str = Console.ReadLine();
            int year = int.Parse(str.Substring(0, 4));
            int month = int.Parse(str.Substring(4, 2));
            int day = int.Parse(str.Substring(6, 2));



            if (year % 400 == 0 || year % 4 == 0 && year % 100 != 0)
            {
                int totalDay = 0;
                switch (month)
                {
                    case 1:
                        {
                            totalDay = day;
                            break;
                        }
                    case 2:
                        {
                            totalDay = 31 + day;
                            break;
                        }
                    case 3:
                        {
                            totalDay = 31 + 29 + day;
                            break;
                        }
                    case 4:
                        {
                            totalDay = 31 + 29 + 31 + day;
                            break;
                        }
                    case 5:
                        {
                            totalDay = 31 + 29 + 31 + 30 + day;
                            break;
                        }
                    case 6:
                        {
                            totalDay = 31 + 29 + 31 + 30 + 31 + day;
                            break;
                        }
                    case 7:
                        {
                            totalDay = 31 + 29 + 31 + 30 + 31 + 30 + day;
                            break;
                        }
                    case 8:
                        {
                            totalDay = 31 + 29 + 31 + 30 + 31 + 30 + 31 + day;
                            break;
                        }
                    case 9:
                        {
                            totalDay = 31 + 29 + 31 + 30 + 31 + 30 + 31 + 31 + day;
                            break;
                        }
                    case 10:
                        {
                            totalDay = 31 + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + day;
                            break;
                        }
                    case 11:
                        {
                            totalDay = 31 + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + day;
                            break;
                        }
                    case 12:
                        {
                            totalDay = 31 + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30 + day;
                            break;
                        }


                }
                Console.WriteLine("{0}是闰年,{1}是一年中的{2}天", year, str, totalDay);
            }
            else
            {
                int totalDay = 0;
                switch (month)
                {
                    case 1:
                        {
                            totalDay = day;
                            break;
                        }
                    case 2:
                        {
                            totalDay = 31 + day;
                            break;
                        }
                    case 3:
                        {
                            totalDay = 31 + 28 + day;
                            break;
                        }
                    case 4:
                        {
                            totalDay = 31 + 28 + 31 + day;
                            break;
                        }
                    case 5:
                        {
                            totalDay = 31 + 28 + 31 + 30 + day;
                            break;

                        }
                    case 6:
                        {
                            totalDay = 31 + 28 + 31 + 30 + 31 + day;
                            break;

                        }
                    case 7:
                        {
                            totalDay = 31 + 28 + 31 + 30 + 31 + 30 + day;
                            break;

                        }
                    case 8:
                        {
                            totalDay = 31 + 28 + 31 + 30 + 31 + 30 + 31 + day;
                            break;

                        }
                    case 9:
                        {
                            totalDay = 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + day;
                            break;

                        }
                    case 10:
                        {
                            totalDay = 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + day;
                            break;

                        }
                    case 11:
                        {
                            totalDay = 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + day;
                            break;

                        }
                    case 12:
                        {
                            totalDay = 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30 + day;
                            break;

                        }
                }
                Console.WriteLine("{0}不是闰年,{1}是一年中的{2}天", year, str, totalDay);
            }
        }
    }
}
